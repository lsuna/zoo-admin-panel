//date for home page

    var d = new Date();
    var n = d.toLocaleDateString();
    document.getElementById("date").innerHTML = n;